export class Config {
  static TELEGRAM_APP_ID = 22862061; // YOUR APP ID EX : 324893724923
  static TELEGRAM_APP_HASH = "5209af9bad0be1f663d657ad05ddfce4"; // YOUR APP HASH EX: "aslkfjkalsjflkasf"
  static MODE = 2; // 1 FOR 1 BY 1 RUN & 2 FOR MASS RUN
  static USEAUTOUPGRADE = true; //USE AUTO UPGRADE OR NO
  static REPAINTER = true; //USE INCORRECT COLOR REPAINTER
  static CUSTOMDELAYINMIN = undefined; //CUSTOM DELAY IN MINUTES EX : 60 = 60 minutes
}
