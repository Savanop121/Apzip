import a1_0x4d367d from 'axios';
import { HttpsProxyAgent } from 'https-proxy-agent';
import { Helper } from '../utils/helper.js';
import a1_0x55b81a from '../utils/logger.js';
export class API {
  constructor(_0x2be483, _0x995040, _0x484189, _0x24bf7d, _0x3ce2f3, _0x1cad08) {
    this.url = _0x484189;
    this.host = _0x24bf7d;
    this.origin = _0x3ce2f3;
    this.referer = _0x1cad08;
    this.ua = Helper.randomUserAgent();
    this.query = _0x2be483;
    this.proxy = _0x995040;
    this.axiosInstance = a1_0x4d367d.create({
      'baseURL': _0x484189,
      'headers': this.generateHeaders()
    });
  }
  ['generateHeaders'](_0x4a31de = this.query) {
    const _0x20bb87 = {
      'Accept': "application/json, text/plain, */*",
      'Accept-Language': "en-US,en;q=0.9,id;q=0.8",
      'Content-Type': "application/json",
      'Sec-Fetch-Dest': "empty",
      'Sec-Fetch-Site': "same-site",
      'Sec-Fetch-Mode': "cors",
      'User-Agent': this.ua,
      'Host': this.host,
      'Origin': this.origin,
      'Referer': this.referer
    };
    if (_0x4a31de) {
      _0x20bb87.Authorization = "Initdata " + _0x4a31de;
    }
    return _0x20bb87;
  }
  async ["fetch"](_0x22e12e, _0x3f07dd = 'GET', _0x4d2a9a, _0x461c5c = {}, _0x1e4be2 = {}) {
    try {
      const _0x476cdf = '' + this.url + _0x22e12e;
      const _0x5428a9 = {
        ..._0x1e4be2,
        ...this.generateHeaders(_0x4d2a9a)
      };
      a1_0x55b81a.info(_0x3f07dd + " : " + _0x476cdf + " " + (this.proxy ? this.proxy : ''));
      a1_0x55b81a.info("Request Header : " + JSON.stringify(_0x5428a9));
      const _0x125c5f = {
        'method': _0x3f07dd,
        'url': _0x476cdf,
        'headers': _0x5428a9
      };
      if (this.proxy) {
        _0x125c5f.httpsAgent = new HttpsProxyAgent(this.proxy);
      }
      if (_0x3f07dd !== "GET") {
        _0x125c5f.data = _0x461c5c;
        a1_0x55b81a.info("Request Body : " + JSON.stringify(_0x461c5c));
      }
      const _0x2a2d26 = await this.axiosInstance.request(_0x125c5f);
      a1_0x55b81a.info("Response : " + _0x2a2d26.status + " " + _0x2a2d26.statusText);
      const _0x4a1fea = {
        'status': _0x2a2d26.status,
        ..._0x2a2d26.data
      };
      a1_0x55b81a.info("Response Data : " + JSON.stringify(_0x4a1fea));
      return _0x4a1fea;
    } catch (_0x193826) {
      a1_0x55b81a.error("Error : " + _0x193826.message);
      throw _0x193826;
    }
  }
}