import { API } from '../api/api.js';
import { Helper } from '../utils/helper.js';
export class Core extends API {
  constructor(_0x53b314, _0x35c0a1, _0x38f0e5, _0x14f7a2) {
    super(_0x35c0a1, _0x14f7a2, "https://notpx.app", "notpx.app", "https://image.notpx.app", 'https://image.notpx.app/');
    this.account = _0x53b314;
    this.query = _0x35c0a1;
    this.queryObj = _0x38f0e5;
    this.colorList = ['#e46e6e', "#FFD635", "#7EED56", "#00CCC0", "#51E9F4", "#94B3FF", "#E4ABFF", "#FF99AA", "#FF99AA"];
    this.completeGameErrorCount = 0x0;
    this.upgradable = {
      'reChargeSpeed': true,
      'energyLimit': true,
      'paintReward': true
    };
    this.found = false;
  }
  async ["getMiningStatus"](_0x5ca462 = false) {
    try {
      if (_0x5ca462) {
        await Helper.delay(0x3e8, this.account, "Getting Mining Status...", this);
      }
      const _0x4296c7 = await this.fetch('/api/v1/mining/status', "GET");
      if (_0x4296c7.status == 0xc8) {
        this.mining = _0x4296c7;
        if (_0x5ca462) {
          await Helper.delay(0x7d0, this.account, "Successfully Get Mining Status", this);
        }
      } else {
        throw Error("Failed To Get Mining Status");
      }
    } catch (_0x1ee0cf) {
      throw _0x1ee0cf;
    }
  }
  async ["getRandomPixelFromCoverage"](_0x2472cb, _0x3bac9e) {
    const _0x16cea0 = [];
    const _0x1a7143 = _0x2472cb % 0x3e8;
    const _0x3d644b = Math.floor(_0x2472cb / 0x3e8);
    const _0x47b833 = _0x3bac9e % 0x3e8;
    const _0x3851fc = Math.floor(_0x3bac9e / 0x3e8);
    for (let _0x120b35 = _0x3d644b; _0x120b35 <= _0x3851fc; _0x120b35++) {
      for (let _0x59ef64 = _0x120b35 === _0x3d644b ? _0x1a7143 : 0x0; _0x59ef64 <= (_0x120b35 === _0x3851fc ? _0x47b833 : 999); _0x59ef64++) {
        const _0xeb36aa = _0x120b35 * 0x3e8 + _0x59ef64;
        _0x16cea0.push(_0xeb36aa);
      }
    }
    return _0x16cea0;
  }
  async ['checkPixel'](_0x3fbe17, _0x19ce40 = '#000000') {
    try {
      const _0x7aec39 = await this.fetch("/api/v1/image/get/" + _0x3fbe17, "GET", undefined);
      if (_0x7aec39.status == 0xc8) {
        if (_0x7aec39.pixel.color != _0x19ce40) {
          await Helper.delay(0x3e8, this.account, "Found Incorrect Pixel " + _0x3fbe17 + " -> Current Color : " + _0x7aec39.pixel.color + " , Correct Color : " + _0x19ce40 + '...', this);
          this.found = true;
        } else {
          this.found = false;
        }
      } else {
        this.found = false;
      }
    } catch (_0x59a62a) {
      this.found = false;
      if (_0x59a62a.message.includes("401")) {
        throw _0x59a62a;
      }
    }
  }
  async ["startPainting"](_0x3577e4, _0x10669b = "#000000") {
    try {
      await Helper.delay(0x3e8, this.account, "Start Painting On Block No " + _0x3577e4 + '...', this);
      const _0x2d93dc = {
        'pixelId': _0x3577e4,
        'newColor': _0x10669b
      };
      const _0x2dbe7a = await this.fetch("/api/v1/repaint/start", "POST", undefined, _0x2d93dc);
      if (_0x2dbe7a.status == 0xc8) {
        await Helper.delay(0xbb8, this.account, "Successfully Painting On Block " + _0x3577e4 + ", with color " + _0x2d93dc.newColor + " \nGot " + (_0x2dbe7a.balance - this.mining.userBalance) + " Points", this);
        await this.getMiningStatus();
      } else {
        await Helper.delay(0x7d0, this.account, "Failed to Painting on Block " + _0x3577e4, this);
      }
    } catch (_0x2952d1) {
      if (_0x2952d1.message.includes("fetch failed")) {
        await Helper.delay(0x7d0, this.account, "Failed to Painting on Block " + _0x3577e4 + " - " + _0x2952d1.message, this);
      } else {
        throw _0x2952d1;
      }
    }
  }
  async ['claimMining']() {
    try {
      await Helper.delay(0x3e8, this.account, "Start Claiming Mining Balance...", this);
      const _0x5537fc = await this.fetch("/api/v1/mining/claim", "GET");
      if (_0x5537fc.status == 0xc8) {
        await Helper.delay(0x7d0, this.account, "Successfully Claim Mining Reward", this);
        await this.getMiningStatus();
      } else {
        await Helper.delay(0x1388, this.account, "Failed To Claim Mining Reward, Skipping...", this);
      }
    } catch (_0x409683) {
      await Helper.delay(0x7d0, this.account, "Failed To Claim Mining Reward, Skipping ...", this);
    }
  }
  async ['completeMissionsX'](_0x5d0f9d) {
    try {
      await Helper.delay(0x1f4, this.account, "Try To Completing Missions X " + _0x5d0f9d + "...", this);
      const _0x1bb2a = await this.fetch("/api/v1/mining/task/check/x?name=" + _0x5d0f9d, 'GET');
      if (_0x1bb2a.status == 0xc8) {
        await Helper.delay(0x3e8, this.account, "Successfully Complete Task X " + _0x5d0f9d, this);
        await this.getMiningStatus();
      } else {
        await Helper.delay(0x3e8, this.account, "Failed to Complete Task X " + _0x5d0f9d + ", Skipping...", this);
      }
    } catch (_0x48ed42) {
      await Helper.delay(0x7d0, this.account, "Failed to Complete Task X " + _0x5d0f9d + ", Skipping...", this);
    }
  }
  async ['upgrade'](_0x3b2c50) {
    try {
      await Helper.delay(0x1f4, this.account, "Try To Upgrading " + _0x3b2c50 + "...", this);
      const _0x231b8c = await this.fetch("/api/v1/mining/boost/check/" + _0x3b2c50, "GET");
      if (_0x231b8c.status == 0xc8) {
        await Helper.delay(0x3e8, this.account, "Successfully Upgrade " + _0x3b2c50, this);
        await this.getMiningStatus();
      } else {
        throw Error("Failed To Upgrade " + _0x3b2c50);
      }
    } catch (_0xdd20ea) {
      this.upgradable[_0x3b2c50] = false;
      await Helper.delay(0x7d0, this.account, "Failed Upgrade " + _0x3b2c50 + " - Insufficient balance", this);
    }
  }
}