import a3_0x30c0c5 from 'input';
import { Helper } from '../utils/helper.js';
import { Api, TelegramClient } from 'telegram';
import { StoreSession } from 'telegram/sessions/StoreSession.js';
import a3_0x5c67a1 from '../utils/logger.js';
import { FloodWaitError } from 'telegram/errors/RPCErrorList.js';
import { Config } from '../../config/config.js';
import { HttpsProxyAgent } from 'https-proxy-agent';
import { LogLevel } from 'telegram/extensions/Logger.js';
export class Telegram {
  ["storeSession"];
  constructor() {
    this.accountName = "accounts";
    this.url = "https://image.notpx.app/";
    this.bot = "notpx_bot";
  }
  async ["init"]() {
    try {
      await this.onBoarding();
    } catch (_0x23ea03) {
      console.log(_0x23ea03);
      a3_0x5c67a1.error('' + JSON.stringify(_0x23ea03));
      throw _0x23ea03;
    }
  }
  async ["onBoarding"]() {
    try {
      let _0x5a9598 = "Welcome to Bot \nBy : Widiskel \n \nLets getting started.\n \nYour Session List:\n";
      const _0x1b8a9f = Helper.getSession("accounts");
      if (_0x1b8a9f.length == 0x0) {
        _0x5a9598 += '<empty>';
      } else {
        for (const _0x11d116 of _0x1b8a9f) {
          _0x5a9598 += "- " + _0x11d116 + "\n";
        }
      }
      _0x5a9598 += "\n \nPlease Choose a menu: \n";
      _0x5a9598 += "\n \n1. Create Account \n2. Reset Account \n3. Start Bot\n4. Query modification\n \nInput your choice :";
      const _0x1a28ae = await a3_0x30c0c5.text(_0x5a9598);
      if (_0x1a28ae == 0x1) {
        await this.accountType();
      } else {
        if (_0x1a28ae == 0x2) {
          Helper.resetAccounts();
          await Helper.delay(0xbb8);
          await this.onBoarding();
        } else {
          if (_0x1a28ae == 0x3) {
            if (Helper.getSession(this.accountName)?.["length"] == 0x0) {
              console.info("You don't have any Accounts, please create first");
              await this.onBoarding();
            }
          } else if (_0x1a28ae == 0x4) {
            await this.queryModificaiton();
          } else {
            console.error("Invalid input, Please try again");
            await this.onBoarding();
          }
        }
      }
    } catch (_0x157f6f) {
      throw _0x157f6f;
    }
  }
  async ["queryModificaiton"]() {
    try {
      const _0x53a06c = Helper.getSession("accounts");
      const _0x33148c = _0x53a06c.filter(_0x2a046f => _0x2a046f.includes("query"));
      let _0x2869ef = "Your Query Account List :\n \n";
      for (const _0x4fc57a of _0x33148c) {
        _0x2869ef += _0x53a06c.indexOf(_0x4fc57a) + 0x1 + ". " + _0x4fc57a + "\n";
      }
      if (_0x33148c.length == 0x0) {
        console.log("You dont have any Query Account.");
        await this.onBoarding();
      } else {
        _0x2869ef += "\n \nPlease Select Query Account for modification:";
      }
      const _0x2e58f8 = await a3_0x30c0c5.text(_0x2869ef);
      if (_0x33148c[_0x2e58f8 - 0x1] != undefined) {
        const _0x525eef = _0x33148c[_0x2e58f8 - 0x1];
        this.accountName = "accounts/" + _0x525eef;
        const _0xdbd537 = "Old Query : " + Helper.readQueryFile(this.accountName + '/query.txt') + "\n \nPlease Enter New Query ";
        const _0x254374 = await a3_0x30c0c5.text(_0xdbd537);
        await Helper.saveQueryFile(this.accountName, _0x254374);
        await Helper.delay(0xbb8);
        await this.onBoarding();
      } else {
        console.error("Invalid input, Please try again");
        await this.queryModificaiton();
      }
    } catch (_0x46ffa6) {
      throw _0x46ffa6;
    }
  }
  async ['sessionCreation']() {
    try {
      if (Config.TELEGRAM_APP_ID == undefined || Config.TELEGRAM_APP_HASH == undefined) {
        throw new Error("Please configure your TELEGRAM_APP_ID and TELEGRAM_APP_HASH first");
      }
      const _0x34cb73 = Helper.getSession("accounts");
      let _0x51f3a2 = "Your Account List :\n \n";
      for (const _0x32d907 of _0x34cb73) {
        _0x51f3a2 += _0x34cb73.indexOf(_0x32d907) + 0x1 + ". " + _0x32d907 + "\n";
      }
      if (_0x34cb73.length == 0x0) {
        _0x51f3a2 += "<empty> \n \nPlease enter Session Name :";
      } else {
        _0x51f3a2 += "\n \nYou already have sessions, cancel(CTRL+C) or create new Session :";
      }
      const _0x50761f = await a3_0x30c0c5.text(_0x51f3a2);
      this.accountName = Helper.createDir("sessions-" + _0x50761f);
      await this.useSession(this.accountName);
      await this.disconnect();
      a3_0x5c67a1.info("Session " + this.accountName + " - Created");
      console.log("Session " + _0x50761f + " - Created, Please Restart The Bot Again");
      this.storeSession.save();
      await Helper.delay(0xbb8);
      process.exit();
    } catch (_0x233f69) {
      throw _0x233f69;
    }
  }
  async ["queryCreation"]() {
    try {
      const _0x1d6c90 = Helper.getSession("accounts");
      let _0x157789 = "Your Account List :\n \n";
      for (const _0x332d00 of _0x1d6c90) {
        _0x157789 += _0x1d6c90.indexOf(_0x332d00) + 0x1 + ". " + _0x332d00 + "\n";
      }
      if (_0x1d6c90.length == 0x0) {
        _0x157789 += "<empty> \n \nPlease enter Account Name :";
      } else {
        _0x157789 += "\n \nYou already have Account, cancel(CTRL+C) or create new Account :";
      }
      const _0x655ee = await a3_0x30c0c5.text(_0x157789);
      this.accountName = Helper.createDir("query-" + _0x655ee);
      const _0x323359 = await a3_0x30c0c5.text("Please Enter Telegram Query : ");
      await Helper.saveQueryFile(this.accountName, _0x323359);
      a3_0x5c67a1.info("Query " + this.accountName + " - Created");
      console.log("Query " + _0x655ee + " - Created, Please Restart The Bot Again");
      await Helper.delay(0xbb8);
      process.exit();
    } catch (_0x434f9f) {
      throw _0x434f9f;
    }
  }
  async ["accountType"]() {
    try {
      const _0x4c1da4 = Helper.getSession('accounts');
      let _0x194daa = "Your Account List :\n \n";
      if (_0x4c1da4.length > 0x0) {
        for (const _0x1099ea of _0x4c1da4) {
          _0x194daa += _0x4c1da4.indexOf(_0x1099ea) + 0x1 + ". " + _0x1099ea + "\n";
        }
      } else {
        _0x194daa += "<empty>\n";
      }
      _0x194daa += "\n \nAvailable Account Type: \n1. Session \n2. Query\n \nPlease Entery Your Choice : ";
      const _0x3ecc0b = await a3_0x30c0c5.text(_0x194daa);
      if (_0x3ecc0b == 0x1) {
        await this.sessionCreation();
      } else if (_0x3ecc0b == 0x2) {
        await this.queryCreation();
      } else {
        console.log("Invalid Input");
        await this.accountType();
      }
    } catch (_0x2c445d) {
      throw _0x2c445d;
    }
  }
  async ["useSession"](_0xbb694d, _0xc4f0b) {
    try {
      this.proxy = _0xc4f0b;
      const _0x46a329 = {
        'connectionRetries': 0x5
      };
      if (this.proxy) {
        _0x46a329.agent = new HttpsProxyAgent(this.proxy);
      }
      this.storeSession = new StoreSession(_0xbb694d);
      this.client = new TelegramClient(this.storeSession, Config.TELEGRAM_APP_ID, Config.TELEGRAM_APP_HASH, _0x46a329);
      this.client.setLogLevel(LogLevel.ERROR);
      this.storeSession.save();
      await this.client.start({
        'phoneNumber': async () => await a3_0x30c0c5.text("Enter your Telegram Phone Number ?"),
        'password': async () => await a3_0x30c0c5.text("Enter your Telegram Password?"),
        'phoneCode': async () => await a3_0x30c0c5.text("Enter your Telegram Verification Code ?"),
        'onError': _0x11ba04 => {
          console.log(_0x11ba04.message);
        }
      });
    } catch (_0xdf9308) {
      throw _0xdf9308;
    }
  }
  async ["resolvePeer"](_0x25e6a5) {
    try {
      a3_0x5c67a1.info("Session " + this.session + " - Resolving Peer");
      while (this.peer == undefined) {
        try {
          this.peer = await this.client.getEntity(this.bot);
          break;
        } catch (_0x3fde69) {
          if (_0x3fde69 instanceof FloodWaitError) {
            const _0x3ebd63 = _0x3fde69.seconds;
            a3_0x5c67a1.warn(this.client.session.serverAddress + " | FloodWait " + _0x3fde69);
            a3_0x5c67a1.info(this.client.session.serverAddress + " | Sleep " + _0x3ebd63 + 's');
            await Helper.delay(_0x3ebd63 * 0x3e8, _0x25e6a5, this.client.session.serverAddress + " | FloodWait " + _0x3fde69);
          } else {
            throw _0x3fde69;
          }
        }
      }
    } catch (_0x289fbd) {
      throw _0x289fbd;
    }
  }
  async ["disconnect"]() {
    await this.client.disconnect();
    await this.client.destroy();
    this.peer = undefined;
    this.accountName = undefined;
  }
  async ["initWebView"]() {
    try {
      const _0x5d385a = await this.client.invoke(new Api.messages.RequestWebView({
        'peer': this.peer,
        'bot': this.peer,
        'fromBotMenu': true,
        'url': this.url,
        'platform': 'android'
      }));
      a3_0x5c67a1.info("Session " + this.session + " - Webview Connected");
      const _0x2d9867 = _0x5d385a.url;
      return Helper.getTelegramQuery(_0x2d9867, 0x3);
    } catch (_0x448c86) {
      throw _0x448c86;
    }
  }
}