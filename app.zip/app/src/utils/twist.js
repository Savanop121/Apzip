import { Twisters } from 'twisters';
import a6_0x2da50a from './logger.js';
import { Core } from '../core/core.js';
class Twist {
  constructor() {
    this.twisters = new Twisters();
  }
  ['log'](_0x406c15 = '', _0x19d4f6 = '', _0x583f8c = new Core(), _0x2e4acc) {
    if (_0x2e4acc == undefined) {
      a6_0x2da50a.info(_0x19d4f6.id + " - " + _0x406c15);
      _0x2e4acc = '-';
    }
    const _0x418c00 = _0x583f8c.mining ?? {};
    const _0x1adecf = _0x418c00.userBalance ?? '-';
    const _0x25fa60 = _0x418c00.charges ?? '-';
    this.twisters.put(_0x19d4f6.id, {
      'text': "\n================= Account " + _0x19d4f6.id + " =============\nName         : " + (_0x19d4f6.firstName ?? 'Unamed') + " " + (_0x19d4f6.lastName ?? '') + " \nBalance      : " + _0x1adecf + "\nCharge       : " + _0x25fa60 + "\n\nStatus : " + _0x406c15 + "\nDelay : " + _0x2e4acc + "\n=============================================="
    });
  }
  ["info"](_0x1ed5e9 = '') {
    this.twisters.put(0x2, {
      'text': "\n==============================================\nInfo : " + _0x1ed5e9 + "\n=============================================="
    });
    return;
  }
  ["clearInfo"]() {
    this.twisters.remove(0x2);
  }
  async ["clear"](_0x4845bb) {
    await this.twisters.flush();
  }
}
export default new Twist();