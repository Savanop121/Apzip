import a4_0xfb5632 from 'moment-timezone';
import a4_0x184282 from 'fs';
import a4_0x4b7718 from 'path';
import { parse } from 'querystring';
import a4_0x28a9e from './twist.js';
export class Helper {
  static ["delay"] = (_0x562902, _0x5cc9f4, _0x4594dd, _0x2c5076) => {
    return new Promise(_0x5d4636 => {
      let _0x43f89a = _0x562902;
      if (_0x5cc9f4 != undefined) {
        a4_0x28a9e.log(_0x4594dd, _0x5cc9f4, _0x2c5076, "Delaying for " + this.msToTime(_0x562902));
      } else {
        a4_0x28a9e.info((_0x4594dd ?? '') + " - Delaying for " + this.msToTime(_0x562902));
      }
      const _0x1aa74f = setInterval(() => {
        _0x43f89a -= 0x3e8;
        if (_0x5cc9f4 != undefined) {
          a4_0x28a9e.log(_0x4594dd, _0x5cc9f4, _0x2c5076, "Delaying for " + this.msToTime(_0x43f89a));
        } else {
          a4_0x28a9e.info((_0x4594dd ?? '') + " - Delaying for " + this.msToTime(_0x43f89a));
        }
        if (_0x43f89a <= 0x0) {
          clearInterval(_0x1aa74f);
          _0x5d4636();
        }
      }, 0x3e8);
      setTimeout(async () => {
        clearInterval(_0x1aa74f);
        await a4_0x28a9e.clearInfo();
        if (_0x5cc9f4) {
          a4_0x28a9e.log(_0x4594dd, _0x5cc9f4, _0x2c5076);
        }
        _0x5d4636();
      }, _0x562902);
    });
  };
  static ["randomUserAgent"]() {
    const _0x5736a2 = ["Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/125.0.6422.80 Mobile/15E148 Safari/604.1", "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 EdgiOS/125.2535.60 Mobile/15E148 Safari/605.1.15", "Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.6422.113 Mobile Safari/537.36 EdgA/124.0.2478.104", "Mozilla/5.0 (Linux; Android 10; Pixel 3 XL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.6422.113 Mobile Safari/537.36 EdgA/124.0.2478.104", "Mozilla/5.0 (Linux; Android 10; VOG-L29) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.6422.113 Mobile Safari/537.36 OPR/76.2.4027.73374", "Mozilla/5.0 (Linux; Android 10; SM-N975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.6422.113 Mobile Safari/537.36 OPR/76.2.4027.73374"];
    return _0x5736a2[Math.floor(Math.random() * _0x5736a2.length)];
  }
  static ["readTime"](_0x152783) {
    const _0x53daf4 = a4_0xfb5632.unix(_0x152783);
    return _0x53daf4.format("YYYY-MM-DD HH:mm:ss");
  }
  static ["getCurrentTimestamp"]() {
    const _0x334bd7 = a4_0xfb5632().tz('Asia/Singapore').unix();
    return _0x334bd7.toString();
  }
  static ["getSession"](_0x20c57b) {
    try {
      if (!a4_0x184282.existsSync("accounts")) {
        a4_0x184282.mkdirSync("accounts");
      }
      const _0x569070 = a4_0x184282.readdirSync(a4_0x4b7718.resolve(_0x20c57b));
      const _0x1133e2 = [];
      _0x569070.forEach(_0x291161 => {
        _0x1133e2.push(_0x291161);
      });
      return _0x1133e2;
    } catch (_0xcb91d5) {
      throw Error("Error reading sessions directory: " + _0xcb91d5 + ',');
    }
  }
  static ["resetAccounts"]() {
    try {
      const _0x5a0058 = a4_0x4b7718.resolve('accounts');
      const _0x404839 = a4_0x184282.readdirSync(_0x5a0058);
      console.log("Deleting Accounts...");
      _0x404839.forEach(_0x28046b => {
        const _0x1c4e5f = a4_0x4b7718.join(_0x5a0058, _0x28046b);
        console.log(_0x1c4e5f);
        a4_0x184282.rm(_0x1c4e5f, {
          'recursive': true,
          'force': true
        }, _0x4a66bd => {
          if (_0x4a66bd) {
            console.error("Error deleting file " + _0x1c4e5f + ':', _0x4a66bd);
          }
        });
      });
      console.info("Account reset successfully. Please restart the bot.");
    } catch (_0x48e16f) {
      console.error("Error deleting accounts: " + _0x48e16f);
      throw _0x48e16f;
    }
  }
  static ["getTelegramQuery"](_0x382f42, _0x27089d) {
    const _0xc3deba = _0x382f42.indexOf('#');
    if (_0xc3deba === -0x1) {
      throw new Error("No query string found in the URL.");
    }
    const _0x232148 = _0x382f42.substring(_0xc3deba + 0x1);
    const _0x2af55c = _0x232148.split('&');
    const _0x29d659 = _0x2af55c[0x0].split('&')[0x0].replace("tgWebAppData=", '');
    if (!_0x29d659) {
      throw new Error("Param not found in the query string.");
    }
    if (_0x27089d == '1') {
      return _0x29d659;
    } else {
      if (_0x27089d == '2') {
        return this.decodeQueryString(_0x29d659);
      } else {
        const _0x271a5c = this.decodeQueryString(_0x29d659);
        return this.jsonToInitParam(_0x271a5c);
      }
    }
  }
  static ["getQueryFromUrl"](_0x5975db) {
    var _0x4e3acd = decodeURIComponent(iframeElement.src);
    var _0xd22b08 = _0x4e3acd.split('#')[0x1] || '';
    var _0x6cc78d = _0xd22b08.split("tgWebAppData=")[0x1] || '';
    var _0x4fcce2 = _0x6cc78d.split('&');
    var _0x475906 = {};
    _0x4fcce2.forEach(_0x19b914 => {
      var [_0x1172b3, _0x4340b0] = _0x19b914.split('=');
      if (_0x1172b3 && _0x4340b0) {
        _0x475906[_0x1172b3] = _0x4340b0;
      }
    });
    var _0x169fde = Object.keys(_0x475906).filter(_0x2b5e2c => !_0x2b5e2c.includes('tgWebApp')).map(_0x2e97f1 => _0x2e97f1 + '=' + _0x475906[_0x2e97f1]).join('&');
    return _0x169fde;
  }
  static ['jsonToInitParam'](_0xe62be1) {
    const _0x2ef7ab = parse(_0xe62be1);
    if (_0x2ef7ab.user) {
      const _0x5beccd = JSON.parse(_0x2ef7ab.user);
      _0x2ef7ab.user = encodeURIComponent(JSON.stringify(_0x5beccd));
    }
    const _0x5034b2 = [];
    for (const [_0x20c48b, _0x520794] of Object.entries(_0x2ef7ab)) {
      _0x5034b2.push(_0x20c48b + '=' + _0x520794);
    }
    const _0x2bdd94 = _0x5034b2.join('&');
    return _0x2bdd94;
  }
  static ["decodeQueryString"](_0x525569) {
    const _0x5ad9ed = decodeURIComponent(_0x525569);
    const _0x29743e = _0x5ad9ed.split('&');
    const _0x183e8e = {};
    _0x29743e.forEach(_0x2180cb => {
      const [_0x55e2fe, _0x401766] = _0x2180cb.split('=');
      if (_0x55e2fe === "user") {
        _0x183e8e[_0x55e2fe] = JSON.parse(decodeURIComponent(_0x401766));
      } else {
        _0x183e8e[_0x55e2fe] = _0x401766;
      }
    });
    const _0x465c32 = [];
    for (const [_0x3734a9, _0x565097] of Object.entries(_0x183e8e)) {
      if (_0x3734a9 === "user") {
        _0x465c32.push(_0x3734a9 + '=' + JSON.stringify(_0x565097));
      } else {
        _0x465c32.push(_0x3734a9 + '=' + _0x565097);
      }
    }
    return _0x465c32.join('&');
  }
  static ["createDir"](_0x2e8e16) {
    try {
      const _0x1d3fa9 = a4_0x4b7718.join("accounts", _0x2e8e16);
      if (!a4_0x184282.existsSync("accounts")) {
        a4_0x184282.mkdirSync("accounts");
      }
      a4_0x184282.mkdirSync(_0x1d3fa9, {
        'recursive': true
      });
      console.log(_0x1d3fa9);
      return _0x1d3fa9;
    } catch (_0x2895fb) {
      throw new Error("Error creating directory: " + _0x2895fb);
    }
  }
  static ["saveQueryFile"](_0x5c4708, _0x3db46e) {
    const _0x4a1500 = a4_0x4b7718.resolve(_0x5c4708, "query.txt");
    a4_0x184282.writeFile(_0x4a1500, _0x3db46e, "utf8", _0x4dae79 => {
      if (_0x4dae79) {
        console.error("Error writing file:", _0x4dae79);
      } else {
        console.log("Query File Created/Modified Successfully.");
      }
    });
  }
  static ["random"](_0x4adb7c, _0x12473a) {
    const _0x39d8fe = Math.floor(Math.random() * (_0x12473a - _0x4adb7c + 0x1)) + _0x4adb7c;
    return _0x39d8fe;
  }
  static ["randomArr"](_0x1368b5) {
    return _0x1368b5[Math.floor(Math.random() * _0x1368b5.length)];
  }
  static ["msToTime"](_0x3bac92) {
    const _0x38ce8e = Math.floor(_0x3bac92 / 3600000);
    const _0x501af7 = _0x3bac92 % 3600000;
    const _0x517aae = Math.floor(_0x501af7 / 60000);
    const _0x3c0c35 = _0x501af7 % 60000;
    const _0x37b9ee = Math.round(_0x3c0c35 / 0x3e8);
    return _0x38ce8e + " Hours " + _0x517aae + " Minutes " + _0x37b9ee + " Seconds";
  }
  static ["queryToJSON"](_0x498954) {
    try {
      const _0x22dda5 = {};
      const _0x400c43 = _0x498954.split('&');
      _0x400c43.forEach(_0xdecef7 => {
        const [_0xc437fc, _0x97bd26] = _0xdecef7.split('=');
        if (_0xc437fc === "user") {
          _0x22dda5[_0xc437fc] = JSON.parse(decodeURIComponent(_0x97bd26));
        } else {
          _0x22dda5[_0xc437fc] = decodeURIComponent(_0x97bd26);
        }
      });
      return _0x22dda5;
    } catch (_0x272f09) {
      throw Error("Invalid Query");
    }
  }
  static ["generateRandomString"](_0xc5b513) {
    let _0x578dd1 = '';
    const _0x17d513 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".length;
    for (let _0x2582a0 = 0x0; _0x2582a0 < _0xc5b513; _0x2582a0++) {
      _0x578dd1 += "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".charAt(Math.floor(Math.random() * _0x17d513));
    }
    return _0x578dd1;
  }
  static ["readQueryFile"](_0x1ebd4a) {
    try {
      const _0x4266fc = a4_0x4b7718.resolve(_0x1ebd4a);
      const _0x147840 = a4_0x184282.readFileSync(_0x4266fc, "utf8");
      return _0x147840;
    } catch (_0x2c3fc4) {
      console.log("No query.txt Files Found");
    }
  }
  static ["launchParamToQuery"](_0x58f76d) {
    const _0x391a42 = new URLSearchParams(_0x58f76d);
    let _0x14589d = decodeURIComponent(_0x391a42.get("tgWebAppData"));
    const _0x4a19dc = new URLSearchParams(_0x14589d);
    let _0x26e915 = decodeURIComponent(_0x4a19dc.get("user"));
    let _0x5b17d5 = JSON.parse(_0x26e915);
    const _0xe6e62 = {
      'query_id': _0x4a19dc.get("query_id"),
      'user': _0x5b17d5,
      'auth_date': _0x4a19dc.get("auth_date"),
      'hash': _0x4a19dc.get("hash")
    };
    const _0x1475eb = JSON.stringify(_0xe6e62.user);
    const _0x240aa1 = encodeURIComponent(_0x1475eb);
    let _0x11f1ee = '';
    if (_0xe6e62.query_id) {
      _0x11f1ee += 'query_id=' + encodeURIComponent(_0xe6e62.query_id) + '&';
    }
    _0x11f1ee += 'user=' + _0x240aa1 + "&auth_date=" + encodeURIComponent(_0xe6e62.auth_date) + "&hash=" + encodeURIComponent(_0xe6e62.hash);
    return _0x11f1ee;
  }
  static ["showSkelLogo"]() {
    console.log("");
  }
}