import { createLogger, format, transports } from 'winston';
import a5_0x582d73 from 'fs';
const {
  combine,
  timestamp,
  printf,
  colorize
} = format;
const customFormat = printf(({
  level: _0xf686b0,
  message: _0x1a3897,
  timestamp: _0x478904
}) => {
  return _0x478904 + " [" + _0xf686b0 + "]: " + _0x1a3897;
});
class Logger {
  constructor() {
    this.logger = createLogger({
      'level': "debug",
      'format': combine(timestamp({
        'format': "YYYY-MM-DD HH:mm:ss"
      }), colorize(), customFormat),
      'transports': [new transports.File({
        'filename': "log/app.log"
      })],
      'exceptionHandlers': [new transports.File({
        'filename': "log/app.log"
      })],
      'rejectionHandlers': [new transports.File({
        'filename': "log/app.log"
      })]
    });
  }
  ["info"](_0xcff2d9) {
    this.logger.info(_0xcff2d9);
  }
  ["warn"](_0x5df043) {
    this.logger.warn(_0x5df043);
  }
  ["error"](_0x308833) {
    this.logger.error(_0x308833);
  }
  ["debug"](_0x4354c1) {
    this.logger.debug(_0x4354c1);
  }
  ["setLevel"](_0x355bb3) {
    this.logger.level = _0x355bb3;
  }
  ['clear']() {
    a5_0x582d73.truncate("log/app.log", 0x0, _0x49d6e8 => {
      if (_0x49d6e8) {
        this.logger.error("Failed to clear the log file: " + _0x49d6e8.message);
      } else {
        this.logger.info("Log file cleared");
      }
    });
  }
}
export default new Logger();