import { Config } from './config/config.js';
import { proxyList } from './config/proxy_list.js';
import { Core } from './src/core/core.js';
import { Telegram } from './src/core/telegram.js';
import { Helper } from './src/utils/helper.js';
import a0_0x362543 from './src/utils/logger.js';
import a0_0x2fed2b from './src/utils/twist.js';
async function operation(_0x16ae2e, _0x72486c, _0x3291c3, _0x195eb0) {
  try {
    const _0x224fcd = new Core(_0x16ae2e, _0x72486c, _0x3291c3, _0x195eb0);
    const _0x3fa96c = Config.REPAINTER ?? true;
    await _0x224fcd.getMiningStatus(true);
    await _0x224fcd.completeMissionsX("notcoin");
    await _0x224fcd.completeMissionsX("notpixel");
    while (_0x224fcd.mining.charges != 0x0) {
      if (_0x3fa96c == true) {
        let _0x1a7245;
        let _0x48290e;
        if (_0x224fcd.found == false) {
          await Helper.delay(0xbb8, _0x16ae2e, "Finding incorrect pixels colors from coverage Area 1...", _0x224fcd);
          const _0x43b626 = await _0x224fcd.getRandomPixelFromCoverage(0x4108e, 0x49180);
          const _0x56503f = await _0x224fcd.getRandomPixelFromCoverage(0x4bc16, 0x53d08);
          _0x1a7245 = [..._0x43b626, ..._0x56503f];
          for (const _0x4d592c of _0x1a7245) {
            await Helper.delay(0x0, _0x16ae2e, "Searching on Area 1...", _0x224fcd);
            await _0x224fcd.checkPixel(_0x4d592c, "#00756F");
            if (_0x224fcd.found == true) {
              await _0x224fcd.startPainting(_0x4d592c, "#00756F");
              break;
            }
          }
        }
        if (_0x224fcd.found == false) {
          await Helper.delay(0xbb8, _0x16ae2e, "Finding incorrect pixels colors from coverage Area 2...", _0x224fcd);
          const _0x4e6d2d = await _0x224fcd.getRandomPixelFromCoverage(0x760a1, 0x79381);
          const _0x28ce66 = await _0x224fcd.getRandomPixelFromCoverage(0x7ba79, 0x7d9cb);
          _0x48290e = [..._0x4e6d2d, ..._0x28ce66];
          for (const _0x436ef9 of _0x1a7245) {
            await Helper.delay(0x0, _0x16ae2e, "Searching on Area 2...", _0x224fcd);
            await _0x224fcd.checkPixel(_0x436ef9, "#2450A4");
            if (_0x224fcd.found == true) {
              await _0x224fcd.startPainting(_0x436ef9, "#2450A4");
              break;
            }
          }
        }
        if (_0x224fcd.found == false) {
          const _0x5a8c34 = Helper.random(0x0, _0x1a7245.length);
          await _0x224fcd.startPainting(_0x1a7245[_0x5a8c34], '#00756F');
        }
        _0x224fcd.found = false;
      } else {
        const _0x153c1c = Helper.random(0x1, 0xf4240);
        await _0x224fcd.startPainting(_0x153c1c);
      }
    }
    await _0x224fcd.claimMining();
    const _0x4e8c2a = Config.USEAUTOUPGRADE ?? true;
    if (_0x4e8c2a) {
      if (_0x224fcd.mining.boosts.reChargeSpeed != 0x7) {
        await _0x224fcd.upgrade('reChargeSpeed');
      }
      if (_0x224fcd.mining.boosts.paintReward != 0xb) {
        await _0x224fcd.upgrade("paintReward");
      }
      if (_0x224fcd.mining.boosts.energyLimit != 0x7) {
        await _0x224fcd.upgrade('energyLimit');
      }
    }
    const _0x5926a7 = Config.MODE ?? 0x2;
    const _0xcda622 = Helper.random(0xbb8, 0x2710);
    const _0x3628d6 = Config.CUSTOMDELAYINMIN ? Config.CUSTOMDELAYINMIN * 0xea60 : undefined;
    if (_0x5926a7 == 0x2) {
      await Helper.delay(_0x3628d6 ? _0x3628d6 : _0xcda622 + _0x224fcd.mining.reChargeTimer, _0x16ae2e, "Account " + _0x16ae2e.id + " Processing Complete, Restarting in " + Helper.msToTime(_0xcda622 + _0x224fcd.mining.reChargeTimer), _0x224fcd);
      await operation(_0x16ae2e, _0x72486c, _0x3291c3, _0x195eb0);
    } else {
      await Helper.delay(0x2710, _0x16ae2e, "Account " + _0x16ae2e.id + " Processing Complete, Continue Using next account in 10 Seconds", _0x224fcd);
      await a0_0x2fed2b.clear(_0x16ae2e);
    }
  } catch (_0x19041c) {
    if (_0x19041c.message.includes('401')) {
      if (_0x16ae2e.type == "query") {
        await Helper.delay(0x3e8, _0x16ae2e, "Error : " + _0x19041c.message + ", Query Is Expired, Please Get New Query");
      } else {
        await Helper.delay(0x1388, _0x16ae2e, "Error : " + _0x19041c.message + ", Query Is Expired, Getting New Query in 5 Seconds");
        const _0x380227 = new Telegram();
        await _0x380227.useSession(_0x16ae2e.accounts, _0x195eb0);
        const _0x3a4850 = await _0x380227.client.getMe();
        _0x3a4850.type = "sessions";
        _0x3a4850.accounts = _0x16ae2e.accounts;
        _0x3a4850.id = _0x3a4850.id.value;
        const _0x2f1747 = await _0x380227.resolvePeer(_0x3a4850).then(async () => {
          return await _0x380227.initWebView();
        })["catch"](_0x5a1979 => {
          throw _0x5a1979;
        });
        const _0x171ff0 = Helper.queryToJSON(_0x2f1747);
        await _0x380227.disconnect();
        await Helper.delay(0x1388, _0x3a4850, "Successfully get new query");
        await operation(_0x3a4850, _0x2f1747, _0x171ff0, _0x195eb0);
      }
    } else {
      await Helper.delay(0x1388, _0x16ae2e, "Error : " + _0x19041c.message + ", Retrying after 5 Seconds");
      await operation(_0x16ae2e, _0x72486c, _0x3291c3, _0x195eb0);
    }
  }
}
let init = false;
async function startBot() {
  return new Promise(async (_0x44de90, _0x2368ea) => {
    try {
      a0_0x362543.info("BOT STARTED");
      const _0x165b20 = await new Telegram();
      if (init == false) {
        await _0x165b20.init();
        init = true;
      }
      const _0x3ca738 = Helper.getSession("accounts");
      const _0x1e2f21 = [];
      if (proxyList.length > 0x0) {
        if (_0x3ca738.length != proxyList.length) {
          _0x2368ea("You have " + _0x3ca738.length + " Session but you provide " + proxyList.length + " Proxy");
        }
      }
      for (const _0x166b62 of _0x3ca738) {
        const _0x42f397 = _0x3ca738.indexOf(_0x166b62);
        const _0x21188b = proxyList.length > 0x0 ? proxyList[_0x42f397] : undefined;
        if (!_0x166b62.includes("query")) {
          await _0x165b20.useSession("accounts/" + _0x166b62, _0x21188b);
          _0x165b20.session = _0x166b62;
          const _0x382300 = await _0x165b20.client.getMe();
          _0x382300.type = 'sessions';
          _0x382300.accounts = "accounts/" + _0x166b62;
          _0x382300.id = _0x382300.id.value;
          const _0x4960aa = await _0x165b20.resolvePeer(_0x382300).then(async () => {
            return await _0x165b20.initWebView();
          })["catch"](_0x53d9d8 => {
            throw _0x53d9d8;
          });
          const _0x3b4f4a = Helper.queryToJSON(_0x4960aa);
          await _0x165b20.disconnect();
          _0x1e2f21.push([_0x382300, _0x4960aa, _0x3b4f4a, _0x21188b]);
        } else {
          let _0x2101ec = Helper.readQueryFile("accounts/" + _0x166b62 + '/query.txt');
          let _0x4a9abd = Helper.queryToJSON(_0x2101ec);
          if (!_0x4a9abd.user) {
            _0x4a9abd = await Helper.queryToJSON(await Helper.launchParamToQuery(_0x2101ec));
            _0x2101ec = await Helper.launchParamToQuery(_0x2101ec);
          }
          const _0x107c40 = _0x4a9abd.user;
          _0x107c40.type = "query";
          _0x107c40.firstName = _0x107c40.first_name;
          _0x107c40.lastName = _0x107c40.last_name;
          _0x1e2f21.push([_0x107c40, _0x2101ec, _0x4a9abd, _0x21188b]);
        }
      }
      const _0x1f44c0 = Config.MODE ?? 0x2;
      if (_0x1f44c0 == 0x2) {
        const _0x241638 = _0x1e2f21.map(async _0x4db219 => {
          await operation(_0x4db219[0x0], _0x4db219[0x1], _0x4db219[0x2], _0x4db219[0x3]);
        });
        await Promise.all(_0x241638);
      } else {
        while (true) {
          for (const _0x4a3296 of _0x1e2f21) {
            await operation(_0x4a3296[0x0], _0x4a3296[0x1], _0x4a3296[0x2], _0x4a3296[0x3]);
          }
          const _0x3f2fee = Config.CUSTOMDELAYINMIN ? Config.CUSTOMDELAYINMIN * 0xea60 : undefined;
          await Helper.delay(_0x3f2fee ? _0x3f2fee : 600000, undefined, "All Account Processing Complete");
          await a0_0x2fed2b.clearInfo();
          conosole.log();
          conosole.log();
          conosole.log("-> New Iteration");
        }
      }
      _0x44de90();
    } catch (_0x5b1729) {
      a0_0x362543.info("BOT STOPPED");
      a0_0x362543.error(JSON.stringify(_0x5b1729));
      _0x2368ea(_0x5b1729);
    }
  });
}
(async () => {
  try {
    a0_0x362543.clear();
    a0_0x362543.info('');
    a0_0x362543.info("Application Started");
    console.log("Not Pixel BOT");
    console.log();
    console.log("By : Insiders");;
    console.log("Join Channel : https://t.me/AirdropInsiderID");
    console.log("Dont forget to run git pull to keep up to date");
    console.log();
    console.log();
    Helper.showSkelLogo();
    await startBot();
  } catch (_0x5dd5c3) {
    await a0_0x2fed2b.clear();
    await a0_0x2fed2b.clearInfo();
    console.log("Error During executing bot", _0x5dd5c3);
    await startBot();
  }
})();